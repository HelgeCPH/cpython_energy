"""Otii TCP Client
"""

__version__ = "2.2.5"
